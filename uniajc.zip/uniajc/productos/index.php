<?php
require_once __DIR__ . '/conexion.php';

$sql = "SELECT p.codigo, p.nombre, p.estado, p.codigo_barras, p.precio, pr.nombre AS proveedor
        FROM producto p
        JOIN proveedor pr ON p.id_proveedor = pr.id_proveedor";
$result = $mysqli->query($sql);
if (!$result) {
    die('Error en la consulta: ' . $mysqli->error);
}
?>
<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Productos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body class="bg-light">
    <div class="container py-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="h3">Lista de Productos</h1>
        <a href="crear_producto.php" class="btn btn-primary">Crear Nuevo Producto</a>
      </div>

      <div class="card">
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-striped table-hover">
              <thead>
                <tr>
                  <th>Código</th>
                  <th>Nombre</th>
                  <th>Estado</th>
                  <th>Código de Barras</th>
                  <th>Precio</th>
                  <th>Proveedor</th>
                  <th>Accones</th>
                </tr>
              </thead>
              <tbody>
                 <?php while ($row = $result->fetch_assoc()): ?>
                  <tr>
                    <td><?php echo htmlspecialchars($row['codigo']); ?></td>
                    <td><?php echo htmlspecialchars($row['nombre']); ?></td>
                    <td><?php echo htmlspecialchars($row['proveedor']); ?></td>
                    <td><?php echo number_format($row['precio'], 2); ?></td>
                    <td><?php echo htmlspecialchars($row['codigo_barras']); ?></td>
                    <td><?php echo $row['estado'] ? 'Activo' : 'Inactivo'; ?></td>
                    <td>
                      <a href="actualizar_producto.php?codigo=<?php echo urlencode($row['codigo']); ?>" class="btn btn-sm btn-warning">Editar</a>
                    </td>
                  </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
