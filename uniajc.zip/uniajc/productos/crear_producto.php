<?php
require_once __DIR__ . '/conexion.php';

$error = '';
$prov_query = 'SELECT id_proveedor, nombre FROM proveedor';
$prov_result = $mysqli->query($prov_query);
if (!$prov_result) {
    die('Error al obtener proveedores: ' . $mysqli->error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nombre = trim(isset($_POST['nombre']) ? $_POST['nombre'] : '');
  $codigo_barras = trim(isset($_POST['codigo_barras']) ? $_POST['codigo_barras'] : '');
  $precio = trim(isset($_POST['precio']) ? $_POST['precio'] : '');
    $estado = isset($_POST['estado']) && $_POST['estado'] === '1' ? 1 : 0;
  $id_proveedor = trim(isset($_POST['id_proveedor']) ? $_POST['id_proveedor'] : '');

    if ($nombre === '' || $precio === '' || $id_proveedor === '') {
        $error = 'Los campos Nombre, Precio y Proveedor son obligatorios.';
    } else {
        $stmt = $mysqli->prepare('INSERT INTO producto (nombre, estado, codigo_barras, precio, id_proveedor) VALUES (?, ?, ?, ?, ?)');
        if (!$stmt) {
            $error = 'Error en la preparación: ' . $mysqli->error;
        } else {
            $stmt->bind_param('sisdi', $nombre, $estado, $codigo_barras, $precio, $id_proveedor);
            if ($stmt->execute()) {
                $stmt->close();
                header('Location: index.php');
                exit;
            } else {
                $error = 'Error al insertar producto: ' . $stmt->error;
            }
        }
    }
} // <-- Ensure this closing brace is present to match the opening 'if' on line 11
?>
<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Crear Producto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body class="bg-light">
    <div class="container py-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="h3">Crear Producto</h1>
        <a href="index.php" class="btn btn-secondary">Volver</a>
      </div>

      <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
      <?php endif; ?>

      <div class="card">
        <div class="card-body">
          <form method="post">
            <div class="mb-3">
              <label class="form-label">Nombre</label>
              <input type="text" name="nombre" class="form-control" value="<?php echo isset($_POST['nombre']) ? htmlspecialchars($_POST['nombre']) : ''; ?>">
            </div>

            <div class="mb-3">
              <label class="form-label">Código de Barras</label>
              <input type="text" name="codigo_barras" class="form-control" value="<?php echo isset($_POST['codigo_barras']) ? htmlspecialchars($_POST['codigo_barras']) : ''; ?>">
            </div>

            <div class="mb-3">
              <label class="form-label">Precio</label>
              <input type="number" step="0.01" name="precio" class="form-control" value="<?php echo isset($_POST['precio']) ? htmlspecialchars($_POST['precio']) : ''; ?>">
            </div>

            <div class="mb-3">
              <label class="form-label">Estado</label>
              <select name="estado" class="form-select">
                <option value="1" <?php echo (isset($_POST['estado']) && $_POST['estado'] === '1') ? 'selected' : ''; ?>>Activo</option>
                <option value="0" <?php echo (isset($_POST['estado']) && $_POST['estado'] === '0') ? 'selected' : ''; ?>>Inactivo</option>
              </select>
            </div>

            <div class="mb-3">
              <label class="form-label">Proveedor</label>
              <select name="id_proveedor" class="form-select">
                <option value="">-- Seleccione un proveedor --</option>
                <?php while ($prov = $prov_result->fetch_assoc()): ?>
                  <option value="<?php echo $prov['id_proveedor']; ?>" <?php echo (isset($_POST['id_proveedor']) && $_POST['id_proveedor'] == $prov['id_proveedor']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($prov['nombre']); ?></option>
                <?php endwhile; ?>
              </select>
            </div>

            <button class="btn btn-success">Guardar</button>
          </form>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
