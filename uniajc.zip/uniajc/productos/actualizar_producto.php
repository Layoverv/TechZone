<?php
require_once __DIR__ . '/conexion.php';

$error = '';

$prov_query = 'SELECT id_proveedor, nombre FROM proveedor';
$prov_result = $mysqli->query($prov_query);
if (!$prov_result) {
    die('Error al obtener proveedores: ' . $mysqli->error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $codigo = $_POST['codigo'] ?? '';
    $nombre = trim($_POST['nombre'] ?? '');
    $codigo_barras = trim($_POST['codigo_barras'] ?? '');
    $precio = trim($_POST['precio'] ?? '');
    $estado = isset($_POST['estado']) && $_POST['estado'] === '1' ? 1 : 0;
    $id_proveedor = trim($_POST['id_proveedor'] ?? '');

    if ($codigo === '' || $nombre === '' || $precio === '' || $id_proveedor === '') {
        $error = 'Código, Nombre, Precio y Proveedor son obligatorios.';
    } else {
        $stmt = $mysqli->prepare('UPDATE producto SET nombre = ?, estado = ?, codigo_barras = ?, precio = ?, id_proveedor = ? WHERE codigo = ?');
        if (!$stmt) {
            $error = 'Error en la preparación: ' . $mysqli->error;
        } else {

            $stmt->bind_param('sisdii', $nombre, $estado, $codigo_barras, $precio, $id_proveedor, $codigo);
            if ($stmt->execute()) {
                $stmt->close();
                header('Location: index.php');
                exit;
            } else {
                $error = 'Error al actualizar: ' . $stmt->error;
            }
        }
    }
}

$codigo_get = $_GET['codigo'] ?? '';
if ($codigo_get === '') {
    die('Falta el parámetro codigo en la URL.');
}

$stmt = $mysqli->prepare('SELECT codigo, nombre, estado, codigo_barras, precio, id_proveedor FROM producto WHERE codigo = ?');
if (!$stmt) {
    die('Error en la preparación: ' . $mysqli->error);
}
$stmt->bind_param('i', $codigo_get);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows === 0) {
    die('Producto no encontrado.');
}
$producto = $res->fetch_assoc();
$stmt->close();

?>
<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Actualizar Producto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body class="bg-light">
    <div class="container py-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="h3">Editar Producto</h1>
        <a href="index.php" class="btn btn-secondary">Volver</a>
      </div>

      <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
      <?php endif; ?>

      <div class="card">
        <div class="card-body">
          <form method="post">
            <input type="hidden" name="codigo" value="<?php echo htmlspecialchars($producto['codigo']); ?>">

            <div class="mb-3">
              <label class="form-label">Nombre</label>
              <input type="text" name="nombre" class="form-control" value="<?php echo htmlspecialchars($producto['nombre']); ?>">
            </div>

            <div class="mb-3">
              <label class="form-label">Código de Barras</label>
              <input type="text" name="codigo_barras" class="form-control" value="<?php echo htmlspecialchars($producto['codigo_barras']); ?>">
            </div>

            <div class="mb-3">
              <label class="form-label">Precio</label>
              <input type="number" step="0.01" name="precio" class="form-control" value="<?php echo htmlspecialchars($producto['precio']); ?>">
            </div>

            <div class="mb-3">
              <label class="form-label">Estado</label>
              <select name="estado" class="form-select">
                <option value="1" <?php echo ($producto['estado']) ? 'selected' : ''; ?>>Activo</option>
                <option value="0" <?php echo (!$producto['estado']) ? 'selected' : ''; ?>>Inactivo</option>
              </select>
            </div>

            <div class="mb-3">
              <label class="form-label">Proveedor</label>
              <select name="id_proveedor" class="form-select">
                <option value="">-- Seleccione un proveedor --</option>
                <?php
                // Rewind result set pointer if necesario
                $prov_result->data_seek(0);
                while ($prov = $prov_result->fetch_assoc()): ?>
                  <option value="<?php echo $prov['id_proveedor']; ?>" <?php echo ($prov['id_proveedor'] == $producto['id_proveedor']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($prov['nombre']); ?></option>
                <?php endwhile; ?>
              </select>
            </div>

            <button class="btn btn-primary">Actualizar</button>
          </form>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
