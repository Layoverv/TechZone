CREATE TABLE IF NOT EXISTS proveedor (
    id_proveedor INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    contacto_email VARCHAR(100) UNIQUE,
    telefono VARCHAR(20)
);


INSERT INTO proveedor (nombre, contacto_email, telefono) VALUES
('Tecno Global S.A.', 'contacto@tecno.com', '555-1001'),
('Distribuidora Alfa', 'info@alfa.net', '555-2002'),
('Suministros Cali', 'ventas@suministroscali.com', '555-3003');


CREATE TABLE IF NOT EXISTS producto (
    codigo INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    estado BOOLEAN NOT NULL DEFAULT TRUE,
    codigo_barras VARCHAR(50) UNIQUE,
    precio DECIMAL(10, 2) NOT NULL,
    id_proveedor INT(11) NOT NULL,
    FOREIGN KEY (id_proveedor) REFERENCES proveedor(id_proveedor)
);
