import { useState } from "react";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { Services } from "./components/Services";
import { Testimonials } from "./components/Testimonials";
import { ContactForm } from "./components/ContactForm";
import { Footer } from "./components/Footer";
import { Toaster } from "./components/ui/sonner";
import { Login } from "./components/admin/Login";
import { AdminLayout } from "./components/admin/AdminLayout";
import { Dashboard } from "./components/admin/Dashboard";
import { ConsultasManager } from "./components/admin/ConsultasManager";
import { TestimoniosManager } from "./components/admin/TestimoniosManager";
import { UsuariosManager } from "./components/admin/UsuariosManager";
import { OperadorDashboard } from "./components/admin/OperadorDashboard";
import { MisConsultas } from "./components/admin/MisConsultas";

export default function App() {
  const [user, setUser] = useState<{ email: string; role: string; name: string } | null>(null);
  const [currentView, setCurrentView] = useState("dashboard");
  const [showAdmin, setShowAdmin] = useState(false);
  const [publicUser, setPublicUser] = useState<{ name: string; email: string } | null>(null);

  const handleLogin = (userData: { email: string; role: string; name: string }) => {
    setUser(userData);
    setShowAdmin(true);
  };

  const handleLogout = () => {
    setUser(null);
    setShowAdmin(false);
    setCurrentView("dashboard");
  };

  const handlePublicUserLogout = () => {
    setPublicUser(null);
  };

  const handleAdminClick = () => {
    setShowAdmin(true);
  };

  // Vista pública
  if (!showAdmin) {
    return (
      <div className="min-h-screen">
        <Header 
          user={publicUser} 
          onLogout={handlePublicUserLogout}
          onAdminClick={handleAdminClick}
        />
        <main>
          <Hero />
          <Services />
          <Testimonials />
          <ContactForm />
        </main>
        <Footer />
        <Toaster />
      </div>
    );
  }

  // Vista de login
  if (!user) {
    return (
      <>
        <Login onLogin={handleLogin} />
        <Toaster />
      </>
    );
  }

  // Vista de admin/operador
  const renderView = () => {
    if (user.role === "admin") {
      switch (currentView) {
        case "dashboard":
          return <Dashboard onNavigate={setCurrentView} />;
        case "consultas":
          return <ConsultasManager />;
        case "testimonios":
          return <TestimoniosManager />;
        case "usuarios":
          return <UsuariosManager />;
        default:
          return <Dashboard onNavigate={setCurrentView} />;
      }
    } else {
      // Vista de operador
      switch (currentView) {
        case "dashboard":
          return <OperadorDashboard onNavigate={setCurrentView} userName={user.name} />;
        case "mis-consultas":
          return <MisConsultas userName={user.name} />;
        case "testimonios":
          return <TestimoniosManager />;
        default:
          return <OperadorDashboard onNavigate={setCurrentView} userName={user.name} />;
      }
    }
  };

  return (
    <>
      <AdminLayout
        currentView={currentView}
        onViewChange={setCurrentView}
        onLogout={handleLogout}
        userName={user.name}
        userRole={user.role}
      >
        {renderView()}
      </AdminLayout>
      <Toaster />
    </>
  );
}
