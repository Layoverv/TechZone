import { useState } from "react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Checkbox } from "../ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "../ui/dialog";
import { UserPlus, Eye, EyeOff, CheckCircle2 } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface RegisterProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSwitchToLogin: () => void;
  onRegisterSuccess: (user: { name: string; email: string }) => void;
}

export function Register({ open, onOpenChange, onSwitchToLogin, onRegisterSuccess }: RegisterProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: ""
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const validateForm = () => {
    if (!formData.name.trim()) {
      toast.error("Por favor, ingresa tu nombre completo");
      return false;
    }
    if (!formData.email.trim()) {
      toast.error("Por favor, ingresa tu correo electrónico");
      return false;
    }
    if (!formData.email.includes("@")) {
      toast.error("Por favor, ingresa un correo electrónico válido");
      return false;
    }
    if (formData.password.length < 6) {
      toast.error("La contraseña debe tener al menos 6 caracteres");
      return false;
    }
    if (formData.password !== formData.confirmPassword) {
      toast.error("Las contraseñas no coinciden");
      return false;
    }
    if (!acceptTerms) {
      toast.error("Debes aceptar los términos y condiciones");
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);

    // Simulación de registro
    setTimeout(() => {
      toast.success("¡Cuenta creada exitosamente! Bienvenido");
      onRegisterSuccess({ name: formData.name, email: formData.email });
      onOpenChange(false);
      setFormData({
        name: "",
        email: "",
        password: "",
        confirmPassword: ""
      });
      setAcceptTerms(false);
      setIsLoading(false);
    }, 1500);
  };

  const passwordStrength = (password: string) => {
    if (password.length === 0) return { strength: 0, text: "", color: "" };
    if (password.length < 6) return { strength: 33, text: "Débil", color: "bg-red-500" };
    if (password.length < 10) return { strength: 66, text: "Media", color: "bg-yellow-500" };
    return { strength: 100, text: "Fuerte", color: "bg-green-500" };
  };

  const strength = passwordStrength(formData.password);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">Crear Cuenta</DialogTitle>
          <DialogDescription>
            Completa el formulario para registrarte
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div>
            <Label htmlFor="register-name">Nombre Completo *</Label>
            <Input
              id="register-name"
              name="name"
              type="text"
              value={formData.name}
              onChange={handleChange}
              placeholder="Juan Pérez"
              required
              disabled={isLoading}
            />
          </div>

          <div>
            <Label htmlFor="register-email">Correo Electrónico *</Label>
            <Input
              id="register-email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="tu@email.com"
              required
              disabled={isLoading}
            />
          </div>

          <div>
            <Label htmlFor="register-password">Contraseña *</Label>
            <div className="relative">
              <Input
                id="register-password"
                name="password"
                type={showPassword ? "text" : "password"}
                value={formData.password}
                onChange={handleChange}
                placeholder="••••••••"
                required
                disabled={isLoading}
                className="pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                disabled={isLoading}
              >
                {showPassword ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>
            {formData.password && (
              <div className="mt-2">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-gray-600">Seguridad de la contraseña</span>
                  <span className={`${
                    strength.strength === 33 ? "text-red-600" :
                    strength.strength === 66 ? "text-yellow-600" :
                    "text-green-600"
                  }`}>
                    {strength.text}
                  </span>
                </div>
                <div className="w-full h-1.5 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${strength.color} transition-all duration-300`}
                    style={{ width: `${strength.strength}%` }}
                  />
                </div>
              </div>
            )}
          </div>

          <div>
            <Label htmlFor="register-confirm-password">Confirmar Contraseña *</Label>
            <div className="relative">
              <Input
                id="register-confirm-password"
                name="confirmPassword"
                type={showConfirmPassword ? "text" : "password"}
                value={formData.confirmPassword}
                onChange={handleChange}
                placeholder="••••••••"
                required
                disabled={isLoading}
                className="pr-10"
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                disabled={isLoading}
              >
                {showConfirmPassword ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>
            {formData.confirmPassword && formData.password === formData.confirmPassword && (
              <div className="flex items-center gap-1 mt-1 text-xs text-green-600">
                <CheckCircle2 className="w-3 h-3" />
                Las contraseñas coinciden
              </div>
            )}
          </div>

          <div className="flex items-start gap-2 pt-2">
            <Checkbox
              id="terms"
              checked={acceptTerms}
              onCheckedChange={(checked) => setAcceptTerms(checked as boolean)}
              disabled={isLoading}
            />
            <label htmlFor="terms" className="text-sm text-gray-600 leading-tight cursor-pointer">
              Acepto los{" "}
              <button
                type="button"
                className="text-blue-600 hover:text-blue-700"
                onClick={() => toast.info("Términos y condiciones próximamente")}
              >
                términos y condiciones
              </button>{" "}
              y la{" "}
              <button
                type="button"
                className="text-blue-600 hover:text-blue-700"
                onClick={() => toast.info("Política de privacidad próximamente")}
              >
                política de privacidad
              </button>
            </label>
          </div>

          <Button type="submit" className="w-full gap-2" disabled={isLoading}>
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Creando cuenta...
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4" />
                Crear Cuenta
              </>
            )}
          </Button>
        </form>

        <div className="mt-4 text-center text-sm">
          <span className="text-gray-600">¿Ya tienes una cuenta? </span>
          <button
            type="button"
            onClick={() => {
              onOpenChange(false);
              onSwitchToLogin();
            }}
            className="text-blue-600 hover:text-blue-700"
          >
            Inicia sesión aquí
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
