import { useState } from "react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { toast } from "sonner@2.0.3";
import { Send, Mail, Phone, MapPin, CheckCircle2 } from "lucide-react";

export function ContactForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    messageType: "",
    subject: "",
    message: ""
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    // Validar nombre
    if (!formData.name.trim()) {
      newErrors.name = "El nombre es obligatorio";
    } else if (formData.name.trim().length < 3) {
      newErrors.name = "El nombre debe tener al menos 3 caracteres";
    }

    // Validar email
    if (!formData.email.trim()) {
      newErrors.email = "El correo electrónico es obligatorio";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Por favor ingresa un correo electrónico válido";
    }

    // Validar tipo de mensaje
    if (!formData.messageType) {
      newErrors.messageType = "Por favor selecciona un tipo de mensaje";
    }

    // Validar asunto
    if (!formData.subject.trim()) {
      newErrors.subject = "El asunto es obligatorio";
    } else if (formData.subject.trim().length < 5) {
      newErrors.subject = "El asunto debe tener al menos 5 caracteres";
    }

    // Validar mensaje
    if (!formData.message.trim()) {
      newErrors.message = "El mensaje es obligatorio";
    } else if (formData.message.trim().length < 10) {
      newErrors.message = "El mensaje debe tener al menos 10 caracteres";
    } else if (formData.message.trim().length > 1000) {
      newErrors.message = "El mensaje no puede exceder 1000 caracteres";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error("Por favor corrige los errores en el formulario", {
        description: "Revisa los campos marcados en rojo"
      });
      return;
    }

    setIsSubmitting(true);
    
    // Simular envío de formulario
    setTimeout(() => {
      toast.success("¡Consulta enviada con éxito!", {
        description: "Nos pondremos en contacto contigo a la brevedad. Gracias por tu mensaje.",
        icon: <CheckCircle2 className="w-5 h-5" />
      });
      setFormData({
        name: "",
        email: "",
        messageType: "",
        subject: "",
        message: ""
      });
      setErrors({});
      setIsSubmitting(false);
    }, 1000);
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Limpiar error del campo al modificarlo
    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  return (
    <section id="consulta" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl mb-4">Envía tu Consulta</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            ¿Tienes preguntas? Estamos aquí para ayudarte. Completa el formulario y te responderemos a la brevedad.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
          <Card className="p-8">
            <h3 className="text-2xl mb-6">Formulario de Contacto</h3>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name" className={errors.name ? "text-red-600" : ""}>
                  Nombre Completo *
                </Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleChange("name", e.target.value)}
                  placeholder="Juan Pérez"
                  className={errors.name ? "border-red-500 focus-visible:ring-red-500" : ""}
                  disabled={isSubmitting}
                />
                {errors.name && (
                  <p className="text-sm text-red-600 mt-1">{errors.name}</p>
                )}
              </div>

              <div>
                <Label htmlFor="email" className={errors.email ? "text-red-600" : ""}>
                  Correo Electrónico *
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleChange("email", e.target.value)}
                  placeholder="juan@ejemplo.com"
                  className={errors.email ? "border-red-500 focus-visible:ring-red-500" : ""}
                  disabled={isSubmitting}
                />
                {errors.email && (
                  <p className="text-sm text-red-600 mt-1">{errors.email}</p>
                )}
              </div>

              <div>
                <Label htmlFor="messageType" className={errors.messageType ? "text-red-600" : ""}>
                  Tipo de Mensaje *
                </Label>
                <Select 
                  value={formData.messageType} 
                  onValueChange={(value) => handleChange("messageType", value)}
                  disabled={isSubmitting}
                >
                  <SelectTrigger className={errors.messageType ? "border-red-500" : ""}>
                    <SelectValue placeholder="Selecciona el tipo de mensaje" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="consulta">Consulta</SelectItem>
                    <SelectItem value="sugerencia">Sugerencia</SelectItem>
                    <SelectItem value="otro">Otro</SelectItem>
                  </SelectContent>
                </Select>
                {errors.messageType && (
                  <p className="text-sm text-red-600 mt-1">{errors.messageType}</p>
                )}
              </div>

              <div>
                <Label htmlFor="subject" className={errors.subject ? "text-red-600" : ""}>
                  Asunto *
                </Label>
                <Input
                  id="subject"
                  value={formData.subject}
                  onChange={(e) => handleChange("subject", e.target.value)}
                  placeholder="¿En qué podemos ayudarte?"
                  className={errors.subject ? "border-red-500 focus-visible:ring-red-500" : ""}
                  disabled={isSubmitting}
                />
                {errors.subject && (
                  <p className="text-sm text-red-600 mt-1">{errors.subject}</p>
                )}
              </div>

              <div>
                <Label htmlFor="message" className={errors.message ? "text-red-600" : ""}>
                  Mensaje * ({formData.message.length}/1000)
                </Label>
                <Textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => handleChange("message", e.target.value)}
                  placeholder="Cuéntanos cómo podemos ayudarte..."
                  rows={5}
                  className={errors.message ? "border-red-500 focus-visible:ring-red-500" : ""}
                  maxLength={1000}
                  disabled={isSubmitting}
                />
                {errors.message && (
                  <p className="text-sm text-red-600 mt-1">{errors.message}</p>
                )}
              </div>

              <Button type="submit" className="w-full gap-2" disabled={isSubmitting}>
                <Send className="w-4 h-4" />
                {isSubmitting ? "Enviando..." : "Enviar Consulta"}
              </Button>

              <p className="text-sm text-gray-500 text-center">
                * Campos obligatorios
              </p>
            </form>
          </Card>

          <div className="space-y-6">
            <Card className="p-6">
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h4 className="text-lg mb-1">Email</h4>
                  <p className="text-gray-600">contacto@minegocio.com</p>
                  <p className="text-gray-600">soporte@minegocio.com</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <h4 className="text-lg mb-1">Teléfono</h4>
                  <p className="text-gray-600">+34 900 123 456</p>
                  <p className="text-gray-600">Lun - Vie: 9:00 - 18:00</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h4 className="text-lg mb-1">Oficina</h4>
                  <p className="text-gray-600">Calle Principal 123</p>
                  <p className="text-gray-600">28001 Madrid, España</p>
                </div>
              </div>
            </Card>

            <Card className="p-6 bg-gradient-to-br from-blue-600 to-purple-600 text-white">
              <h4 className="text-xl mb-2">¿Necesitas ayuda inmediata?</h4>
              <p className="mb-4 text-blue-50">
                Nuestro equipo está disponible para atender tus consultas urgentes.
              </p>
              <Button variant="secondary" className="w-full">
                Chat en Vivo
              </Button>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
