import { useState } from "react";
import { Button } from "./ui/button";
import { LogIn, UserPlus, Shield, User, LogOut } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { UserLogin } from "./auth/UserLogin";
import { Register } from "./auth/Register";

interface HeaderProps {
  user?: { name: string; email: string } | null;
  onLogout?: () => void;
  onAdminClick?: () => void;
}

export function Header({ user, onLogout, onAdminClick }: HeaderProps) {
  const [showLogin, setShowLogin] = useState(false);
  const [showRegister, setShowRegister] = useState(false);
  const [loggedUser, setLoggedUser] = useState(user);

  const handleAdminAccess = () => {
    if (onAdminClick) {
      onAdminClick();
    }
  };

  const handleLoginSuccess = (userData: { name: string; email: string }) => {
    setLoggedUser(userData);
  };

  const handleRegisterSuccess = (userData: { name: string; email: string }) => {
    setLoggedUser(userData);
  };

  const handleLogout = () => {
    setLoggedUser(null);
    if (onLogout) onLogout();
  };

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
              <span className="text-white">B</span>
            </div>
            <span>Mi Negocio</span>
          </div>
          
          <nav className="hidden md:flex items-center gap-6">
            <a href="#inicio" className="text-gray-600 hover:text-gray-900 transition-colors">
              Inicio
            </a>
            <a href="#servicios" className="text-gray-600 hover:text-gray-900 transition-colors">
              Servicios
            </a>
            <a href="#testimonios" className="text-gray-600 hover:text-gray-900 transition-colors">
              Testimonios
            </a>
            <a href="#contacto" className="text-gray-600 hover:text-gray-900 transition-colors">
              Contacto
            </a>
          </nav>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={handleAdminAccess}>
              <Shield className="w-4 h-4 mr-2" />
              Admin
            </Button>
            
            {loggedUser ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-2">
                    <div className="w-6 h-6 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                      <User className="w-3 h-3 text-white" />
                    </div>
                    <span className="hidden sm:inline">{loggedUser.name}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>Mi Cuenta</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem disabled>
                    <User className="w-4 h-4 mr-2" />
                    Perfil
                  </DropdownMenuItem>
                  <DropdownMenuItem disabled>
                    <span className="text-sm text-gray-600">{loggedUser.email}</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="w-4 h-4 mr-2" />
                    Cerrar Sesión
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <>
                <Button variant="ghost" size="sm" onClick={() => setShowLogin(true)}>
                  <LogIn className="w-4 h-4 mr-2" />
                  Iniciar Sesión
                </Button>
                <Button size="sm" onClick={() => setShowRegister(true)}>
                  <UserPlus className="w-4 h-4 mr-2" />
                  Registrarse
                </Button>
              </>
            )}
          </div>
        </div>
      </header>

      <UserLogin
        open={showLogin}
        onOpenChange={setShowLogin}
        onSwitchToRegister={() => setShowRegister(true)}
        onLoginSuccess={handleLoginSuccess}
      />

      <Register
        open={showRegister}
        onOpenChange={setShowRegister}
        onSwitchToLogin={() => setShowLogin(true)}
        onRegisterSuccess={handleRegisterSuccess}
      />
    </>
  );
}
