import { useState } from "react";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Button } from "./ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Checkbox } from "./ui/checkbox";
import { Star, Calendar, Plus } from "lucide-react";
import { toast } from "sonner@2.0.3";

const testimonials = [
  {
    name: "María González",
    role: "CEO, TechStart",
    image: "https://images.unsplash.com/photo-1610208033812-c0d714ad9b5a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGN1c3RvbWVyJTIwdGVzdGltb25pYWx8ZW58MXx8fHwxNzYyMTAwMzIxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    content: "Trabajar con este equipo transformó completamente nuestra empresa. Su enfoque profesional y soluciones innovadoras nos ayudaron a duplicar nuestros ingresos en solo 6 meses.",
    rating: 5,
    date: "15 Oct 2024",
    isAnonymous: false,
    approved: true
  },
  {
    name: "Carlos Ruiz",
    role: "Director, Innovación SA",
    image: "https://images.unsplash.com/photo-1758518729685-f88df7890776?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB0ZWFtJTIwbWVldGluZ3xlbnwxfHx8fDE3NjIwMzA2NzV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    content: "Excelente servicio y atención personalizada. Nos ayudaron a implementar procesos digitales que mejoraron significativamente nuestra productividad.",
    rating: 5,
    date: "22 Sep 2024",
    isAnonymous: false,
    approved: true
  },
  {
    name: "Ana Martínez",
    role: "Fundadora, Desarrollo Plus",
    image: "https://images.unsplash.com/photo-1610208033812-c0d714ad9b5a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGN1c3RvbWVyJTIwdGVzdGltb25pYWx8ZW58MXx8fHwxNzYyMTAwMzIxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    content: "La mejor inversión que hicimos para nuestro negocio. El equipo es profesional, comprometido y siempre disponible para resolver cualquier duda.",
    rating: 5,
    date: "5 Nov 2024",
    isAnonymous: false,
    approved: true
  },
  {
    name: "Anónimo",
    role: "Cliente",
    image: "",
    content: "Muy contento con los resultados obtenidos. Recomiendo sus servicios sin dudarlo. Han superado todas mis expectativas.",
    rating: 4,
    date: "18 Oct 2024",
    isAnonymous: true,
    approved: true
  },
  {
    name: "Jorge López",
    role: "Gerente, Soluciones Tech",
    image: "https://images.unsplash.com/photo-1758518729685-f88df7890776?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjB0ZWFtJTIwbWVldGluZ3xlbnwxfHx8fDE3NjIwMzA2NzV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    content: "Profesionalismo de primer nivel. Nos ayudaron a escalar nuestro negocio de manera sostenible y efectiva.",
    rating: 5,
    date: "1 Nov 2024",
    isAnonymous: false,
    approved: true
  },
  {
    name: "Anónimo",
    role: "Empresario",
    image: "",
    content: "Gran experiencia trabajando con ellos. Los resultados hablan por sí solos.",
    rating: 5,
    date: "28 Oct 2024",
    isAnonymous: true,
    approved: true
  }
];

export function Testimonials() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    role: "",
    message: "",
    rating: 5,
    isAnonymous: false
  });

  const approvedTestimonials = testimonials.filter(t => t.approved);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validaciones
    if (!formData.isAnonymous) {
      if (!formData.name.trim()) {
        toast.error("Por favor ingresa tu nombre", {
          description: "O marca la opción 'Enviar como anónimo'"
        });
        return;
      }
      if (!formData.role.trim()) {
        toast.error("Por favor ingresa tu cargo/empresa");
        return;
      }
    }

    if (!formData.message.trim()) {
      toast.error("Por favor escribe tu testimonio");
      return;
    }

    if (formData.message.trim().length < 20) {
      toast.error("El testimonio debe tener al menos 20 caracteres");
      return;
    }

    if (formData.message.trim().length > 500) {
      toast.error("El testimonio no puede exceder 500 caracteres");
      return;
    }

    toast.success("¡Gracias por tu testimonio!", {
      description: "Tu testimonio será revisado por nuestro equipo y publicado en breve."
    });
    setFormData({
      name: "",
      role: "",
      message: "",
      rating: 5,
      isAnonymous: false
    });
    setIsDialogOpen(false);
  };

  return (
    <section id="testimonios" className="py-20 bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl mb-4">Lo Que Dicen Nuestros Clientes</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Miles de empresas confían en nosotros para impulsar su crecimiento
          </p>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="mt-6 gap-2">
                <Plus className="w-4 h-4" />
                Enviar Testimonio
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Comparte tu Experiencia</DialogTitle>
                <DialogDescription>
                  Tu opinión es muy importante para nosotros. Comparte tu experiencia trabajando con nuestro equipo.
                </DialogDescription>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="anonymous"
                    checked={formData.isAnonymous}
                    onCheckedChange={(checked) => 
                      setFormData(prev => ({ ...prev, isAnonymous: checked === true }))
                    }
                  />
                  <Label htmlFor="anonymous" className="text-sm">
                    Enviar como anónimo
                  </Label>
                </div>

                {!formData.isAnonymous && (
                  <>
                    <div>
                      <Label htmlFor="testimonial-name">Nombre Completo *</Label>
                      <Input
                        id="testimonial-name"
                        value={formData.name}
                        onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="María González"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="testimonial-role">Cargo/Empresa *</Label>
                      <Input
                        id="testimonial-role"
                        value={formData.role}
                        onChange={(e) => setFormData(prev => ({ ...prev, role: e.target.value }))}
                        placeholder="CEO, Mi Empresa"
                        required
                      />
                    </div>
                  </>
                )}

                <div>
                  <Label htmlFor="testimonial-rating">Calificación *</Label>
                  <div className="flex gap-2 mt-2">
                    {[1, 2, 3, 4, 5].map((rating) => (
                      <button
                        key={rating}
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, rating }))}
                        className="focus:outline-none"
                      >
                        <Star 
                          className={`w-8 h-8 ${
                            rating <= formData.rating 
                              ? "fill-yellow-400 text-yellow-400" 
                              : "text-gray-300"
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="testimonial-message">Tu Testimonio *</Label>
                  <Textarea
                    id="testimonial-message"
                    value={formData.message}
                    onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
                    placeholder="Comparte tu experiencia..."
                    rows={4}
                    required
                  />
                </div>

                <div className="flex gap-2 justify-end pt-4">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit">
                    Enviar Testimonio
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {approvedTestimonials.map((testimonial, index) => (
            <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className="flex gap-1">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star 
                      key={i} 
                      className={`w-4 h-4 ${
                        i < testimonial.rating 
                          ? "fill-yellow-400 text-yellow-400" 
                          : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <Calendar className="w-3 h-3" />
                  {testimonial.date}
                </div>
              </div>
              
              <p className="text-gray-600 mb-6">"{testimonial.content}"</p>
              
              <div className="flex items-center gap-3 pt-4 border-t">
                <Avatar>
                  {!testimonial.isAnonymous && testimonial.image ? (
                    <AvatarImage src={testimonial.image} alt={testimonial.name} />
                  ) : null}
                  <AvatarFallback className={testimonial.isAnonymous ? "bg-gray-300" : ""}>
                    {testimonial.isAnonymous ? "?" : testimonial.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className={testimonial.isAnonymous ? "text-gray-500 italic" : ""}>
                    {testimonial.name}
                  </div>
                  <div className="text-sm text-gray-600">{testimonial.role}</div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
