import { Button } from "./ui/button";
import { ArrowRight, MessageSquare, Star } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Hero() {
  return (
    <section id="inicio" className="relative overflow-hidden bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-20 md:py-32">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-full">
              <Star className="w-4 h-4" />
              <span className="text-sm">Soluciones de Negocios Confiables</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl">
              Transformamos tu Negocio al Siguiente Nivel
            </h1>
            
            <p className="text-xl text-gray-600">
              Ofrecemos soluciones innovadoras y personalizadas para impulsar el crecimiento de tu empresa. Con más de 10 años de experiencia, ayudamos a negocios a alcanzar sus objetivos.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button size="lg" className="gap-2" onClick={() => document.getElementById('contacto')?.scrollIntoView({ behavior: 'smooth' })}>
                Contáctanos
                <ArrowRight className="w-5 h-5" />
              </Button>
              
              <Button size="lg" variant="outline" className="gap-2" onClick={() => document.getElementById('testimonios')?.scrollIntoView({ behavior: 'smooth' })}>
                <Star className="w-5 h-5" />
                Ver Testimonios
              </Button>
              
              <Button size="lg" variant="outline" className="gap-2" onClick={() => document.getElementById('consulta')?.scrollIntoView({ behavior: 'smooth' })}>
                <MessageSquare className="w-5 h-5" />
                Enviar Consulta
              </Button>
            </div>

            <div className="flex items-center gap-8 pt-8 border-t">
              <div>
                <div className="text-3xl">500+</div>
                <div className="text-sm text-gray-600">Clientes Satisfechos</div>
              </div>
              <div>
                <div className="text-3xl">98%</div>
                <div className="text-sm text-gray-600">Tasa de Satisfacción</div>
              </div>
              <div>
                <div className="text-3xl">10+</div>
                <div className="text-sm text-gray-600">Años de Experiencia</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-tr from-blue-600/20 to-purple-600/20 rounded-2xl blur-3xl"></div>
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1758630737900-a28682c5aa69?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMG9mZmljZSUyMG1vZGVybnxlbnwxfHx8fDE3NjIxMjkwMTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Oficina moderna"
              className="relative rounded-2xl shadow-2xl w-full h-[500px] object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
