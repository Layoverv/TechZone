import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { 
  MessageSquare, 
  Star, 
  UserCheck, 
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertCircle
} from "lucide-react";

interface DashboardProps {
  onNavigate: (view: string) => void;
}

// Datos mock
const stats = {
  consultasTotal: 127,
  consultasPendientes: 23,
  consultasEnProceso: 45,
  consultasCompletadas: 59,
  testimoniosPendientes: 8,
  testimoniosAprobados: 34,
  leadsActivos: 89,
  tasaConversion: 32
};

const recentActivities = [
  { id: 1, type: "consulta", action: "Nueva consulta recibida", name: "Juan Pérez", time: "Hace 5 min" },
  { id: 2, type: "testimonio", action: "Testimonio pendiente de aprobación", name: "María García", time: "Hace 15 min" },
  { id: 3, type: "consulta", action: "Consulta asignada a operador", name: "Carlos López", time: "Hace 1 hora" },
  { id: 4, type: "testimonio", action: "Testimonio aprobado", name: "Ana Martínez", time: "Hace 2 horas" },
  { id: 5, type: "consulta", action: "Consulta completada", name: "Roberto Díaz", time: "Hace 3 horas" }
];

export function Dashboard({ onNavigate }: DashboardProps) {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl mb-2">Dashboard</h1>
        <p className="text-gray-600">Resumen general de actividades y estadísticas</p>
      </div>

      {/* Estadísticas Principales */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <MessageSquare className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-2xl">{stats.consultasTotal}</span>
          </div>
          <div className="mb-1">Total Consultas</div>
          <div className="text-sm text-gray-600">{stats.consultasPendientes} pendientes</div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <Star className="w-6 h-6 text-purple-600" />
            </div>
            <span className="text-2xl">{stats.testimoniosAprobados}</span>
          </div>
          <div className="mb-1">Testimonios Aprobados</div>
          <div className="text-sm text-gray-600">{stats.testimoniosPendientes} pendientes</div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <UserCheck className="w-6 h-6 text-green-600" />
            </div>
            <span className="text-2xl">{stats.leadsActivos}</span>
          </div>
          <div className="mb-1">Leads Activos</div>
          <div className="text-sm text-gray-600">En seguimiento</div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-orange-600" />
            </div>
            <span className="text-2xl">{stats.tasaConversion}%</span>
          </div>
          <div className="mb-1">Tasa de Conversión</div>
          <div className="text-sm text-gray-600">Este mes</div>
        </Card>
      </div>

      {/* Estado de Consultas */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <Clock className="w-5 h-5 text-orange-600" />
            <h3 className="text-lg">Pendientes</h3>
          </div>
          <div className="text-3xl mb-2">{stats.consultasPendientes}</div>
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full"
            onClick={() => onNavigate("consultas")}
          >
            Ver Consultas
          </Button>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <AlertCircle className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg">En Proceso</h3>
          </div>
          <div className="text-3xl mb-2">{stats.consultasEnProceso}</div>
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full"
            onClick={() => onNavigate("consultas")}
          >
            Ver Consultas
          </Button>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <CheckCircle2 className="w-5 h-5 text-green-600" />
            <h3 className="text-lg">Completadas</h3>
          </div>
          <div className="text-3xl mb-2">{stats.consultasCompletadas}</div>
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full"
            onClick={() => onNavigate("consultas")}
          >
            Ver Consultas
          </Button>
        </Card>
      </div>

      {/* Enlaces Rápidos */}
      <Card className="p-6">
        <h3 className="text-lg mb-4">Accesos Rápidos</h3>
        <div className="grid md:grid-cols-3 gap-4">
          <Button 
            variant="outline" 
            className="justify-start gap-2"
            onClick={() => onNavigate("consultas")}
          >
            <MessageSquare className="w-4 h-4" />
            Gestionar Consultas
          </Button>
          <Button 
            variant="outline" 
            className="justify-start gap-2"
            onClick={() => onNavigate("testimonios")}
          >
            <Star className="w-4 h-4" />
            Gestionar Testimonios
          </Button>
          <Button 
            variant="outline" 
            className="justify-start gap-2"
            onClick={() => onNavigate("usuarios")}
          >
            <UserCheck className="w-4 h-4" />
            Gestionar Usuarios
          </Button>
        </div>
      </Card>

      {/* Actividad Reciente */}
      <Card className="p-6">
        <h3 className="text-lg mb-4">Actividad Reciente</h3>
        <div className="space-y-4">
          {recentActivities.map((activity) => (
            <div key={activity.id} className="flex items-start gap-4 pb-4 border-b last:border-b-0 last:pb-0">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                activity.type === "consulta" ? "bg-blue-100" : "bg-purple-100"
              }`}>
                {activity.type === "consulta" ? (
                  <MessageSquare className="w-5 h-5 text-blue-600" />
                ) : (
                  <Star className="w-5 h-5 text-purple-600" />
                )}
              </div>
              <div className="flex-1">
                <div>{activity.action}</div>
                <div className="text-sm text-gray-600">{activity.name}</div>
              </div>
              <div className="text-sm text-gray-500">{activity.time}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
