import { useState } from "react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { Badge } from "../ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "../ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "../ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../ui/tabs";
import { Search, Eye, Clock, AlertCircle, CheckCircle2 } from "lucide-react";
import { toast } from "sonner@2.0.3";

// Datos mock - filtrados por operador logueado
const mockConsultas = [
  {
    id: 1,
    nombre: "Juan Pérez",
    email: "juan@email.com",
    tipo: "consulta",
    asunto: "Consultoría Estratégica",
    mensaje: "Me gustaría saber más sobre sus servicios de consultoría para mi empresa...",
    estado: "pendiente",
    fecha: "2024-11-03",
    fechaAsignacion: "2024-11-03 09:00",
    asignadoA: "Operador 1",
    notas: [],
    prioridad: "alta"
  },
  {
    id: 2,
    nombre: "María García",
    email: "maria@email.com",
    tipo: "sugerencia",
    asunto: "Mejora en servicio",
    mensaje: "Sería genial si pudieran ofrecer soporte 24/7...",
    estado: "en_proceso",
    fecha: "2024-11-02",
    fechaAsignacion: "2024-11-02 10:30",
    asignadoA: "Operador 1",
    notas: ["Cliente interesado en servicios premium", "Llamada programada para mañana"]
  },
  {
    id: 3,
    nombre: "Carlos López",
    email: "carlos@email.com",
    tipo: "consulta",
    asunto: "Transformación Digital",
    mensaje: "Necesito ayuda para digitalizar mi empresa de servicios...",
    estado: "en_proceso",
    fecha: "2024-11-01",
    fechaAsignacion: "2024-11-01 14:00",
    asignadoA: "Operador 1",
    notas: ["Primera reunión realizada", "Preparar propuesta"]
  },
  {
    id: 4,
    nombre: "Ana Martínez",
    email: "ana@email.com",
    tipo: "consulta",
    asunto: "Capacitación de equipos",
    mensaje: "¿Ofrecen programas de capacitación personalizados?",
    estado: "completada",
    fecha: "2024-10-30",
    fechaAsignacion: "2024-10-30 11:00",
    asignadoA: "Operador 1",
    notas: ["Propuesta enviada y aceptada", "Cliente satisfecho"]
  },
  {
    id: 5,
    nombre: "Roberto Díaz",
    email: "roberto@email.com",
    tipo: "otro",
    asunto: "Información sobre precios",
    mensaje: "Me gustaría conocer sus tarifas...",
    estado: "pendiente",
    fecha: "2024-11-03",
    fechaAsignacion: "2024-11-03 15:30",
    asignadoA: "Operador 1",
    notas: []
  }
];

interface MisConsultasProps {
  userName: string;
}

export function MisConsultas({ userName }: MisConsultasProps) {
  const [consultas, setConsultas] = useState(mockConsultas);
  const [selectedConsulta, setSelectedConsulta] = useState<typeof mockConsultas[0] | null>(null);
  const [filterEstado, setFilterEstado] = useState("todos");
  const [searchTerm, setSearchTerm] = useState("");
  const [nuevaNota, setNuevaNota] = useState("");
  const [activeTab, setActiveTab] = useState("todas");

  const filteredConsultas = consultas.filter(c => {
    const matchEstado = filterEstado === "todos" || c.estado === filterEstado;
    const matchSearch = c.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       c.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       c.asunto.toLowerCase().includes(searchTerm.toLowerCase());
    const matchTab = activeTab === "todas" || c.estado === activeTab;
    return matchEstado && matchSearch && matchTab;
  });

  const handleEstadoChange = (newEstado: string) => {
    if (selectedConsulta) {
      setConsultas(consultas.map(c => 
        c.id === selectedConsulta.id ? { ...c, estado: newEstado } : c
      ));
      setSelectedConsulta({ ...selectedConsulta, estado: newEstado });
      toast.success("Estado actualizado correctamente");
    }
  };

  const handleAddNota = () => {
    if (selectedConsulta && nuevaNota.trim()) {
      const fechaHora = new Date().toLocaleString('es-ES', { 
        day: '2-digit', 
        month: '2-digit', 
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
      const notaConFecha = `[${fechaHora}] ${nuevaNota}`;
      const updatedNotas = [...selectedConsulta.notas, notaConFecha];
      setConsultas(consultas.map(c => 
        c.id === selectedConsulta.id ? { ...c, notas: updatedNotas } : c
      ));
      setSelectedConsulta({ ...selectedConsulta, notas: updatedNotas });
      setNuevaNota("");
      toast.success("Nota añadida");
    }
  };

  const getEstadoBadge = (estado: string) => {
    const variants: Record<string, { variant: "default" | "secondary" | "destructive" | "outline", label: string, icon: any }> = {
      pendiente: { variant: "outline", label: "Pendiente", icon: Clock },
      en_proceso: { variant: "default", label: "En Proceso", icon: AlertCircle },
      completada: { variant: "secondary", label: "Completada", icon: CheckCircle2 }
    };
    const config = variants[estado] || variants.pendiente;
    const Icon = config.icon;
    return (
      <Badge variant={config.variant} className="gap-1">
        <Icon className="w-3 h-3" />
        {config.label}
      </Badge>
    );
  };

  const getTipoBadge = (tipo: string) => {
    const colors: Record<string, string> = {
      consulta: "bg-blue-100 text-blue-700",
      sugerencia: "bg-green-100 text-green-700",
      otro: "bg-gray-100 text-gray-700"
    };
    return (
      <Badge variant="outline" className={colors[tipo]}>
        {tipo.charAt(0).toUpperCase() + tipo.slice(1)}
      </Badge>
    );
  };

  const getPrioridadIndicator = (consulta: typeof mockConsultas[0]) => {
    if (consulta.prioridad === "alta") {
      return <div className="w-2 h-2 bg-red-500 rounded-full" title="Prioridad Alta" />;
    }
    return null;
  };

  const countByEstado = (estado: string) => {
    return consultas.filter(c => c.estado === estado).length;
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl mb-2">Mis Consultas Asignadas</h1>
        <p className="text-gray-600">
          Gestiona las consultas que te han sido asignadas. Total: {consultas.length} consultas
        </p>
      </div>

      {/* Resumen Rápido */}
      <div className="grid md:grid-cols-3 gap-4">
        <Card className="p-4 bg-orange-50 border-orange-200">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-orange-600 mb-1">Pendientes</div>
              <div className="text-2xl">{countByEstado("pendiente")}</div>
            </div>
            <Clock className="w-8 h-8 text-orange-600" />
          </div>
        </Card>
        <Card className="p-4 bg-blue-50 border-blue-200">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-blue-600 mb-1">En Proceso</div>
              <div className="text-2xl">{countByEstado("en_proceso")}</div>
            </div>
            <AlertCircle className="w-8 h-8 text-blue-600" />
          </div>
        </Card>
        <Card className="p-4 bg-green-50 border-green-200">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-green-600 mb-1">Completadas</div>
              <div className="text-2xl">{countByEstado("completada")}</div>
            </div>
            <CheckCircle2 className="w-8 h-8 text-green-600" />
          </div>
        </Card>
      </div>

      {/* Filtros */}
      <Card className="p-6">
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <Label>Buscar</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Nombre, email, asunto..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          <div>
            <Label>Filtrar por Estado</Label>
            <Select value={filterEstado} onValueChange={setFilterEstado}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos los estados</SelectItem>
                <SelectItem value="pendiente">Pendiente</SelectItem>
                <SelectItem value="en_proceso">En Proceso</SelectItem>
                <SelectItem value="completada">Completada</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      {/* Tabs y Tabla */}
      <Card>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="border-b px-6 pt-4">
            <TabsList>
              <TabsTrigger value="todas">
                Todas ({consultas.length})
              </TabsTrigger>
              <TabsTrigger value="pendiente">
                Pendientes ({countByEstado("pendiente")})
              </TabsTrigger>
              <TabsTrigger value="en_proceso">
                En Proceso ({countByEstado("en_proceso")})
              </TabsTrigger>
              <TabsTrigger value="completada">
                Completadas ({countByEstado("completada")})
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value={activeTab} className="m-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-8"></TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Asunto</TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead>Fecha Asignación</TableHead>
                  <TableHead>Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredConsultas.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                      No hay consultas para mostrar
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredConsultas.map((consulta) => (
                    <TableRow key={consulta.id} className="cursor-pointer hover:bg-gray-50">
                      <TableCell>{getPrioridadIndicator(consulta)}</TableCell>
                      <TableCell>
                        <div>
                          <div>{consulta.nombre}</div>
                          <div className="text-xs text-gray-500">{consulta.email}</div>
                        </div>
                      </TableCell>
                      <TableCell>{getTipoBadge(consulta.tipo)}</TableCell>
                      <TableCell className="max-w-xs truncate">{consulta.asunto}</TableCell>
                      <TableCell>{getEstadoBadge(consulta.estado)}</TableCell>
                      <TableCell className="text-sm">{consulta.fechaAsignacion}</TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setSelectedConsulta(consulta)}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </TabsContent>
        </Tabs>
      </Card>

      {/* Dialog de Detalle y Gestión */}
      <Dialog open={!!selectedConsulta} onOpenChange={() => setSelectedConsulta(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Gestión de Consulta #{selectedConsulta?.id}</DialogTitle>
            <DialogDescription>
              Actualiza el estado y añade notas de seguimiento
            </DialogDescription>
          </DialogHeader>

          {selectedConsulta && (
            <div className="space-y-6">
              {/* Estado Actual */}
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <div className="text-sm text-gray-600 mb-1">Estado Actual</div>
                  {getEstadoBadge(selectedConsulta.estado)}
                </div>
                <div className="text-right">
                  <div className="text-sm text-gray-600">Asignado desde</div>
                  <div className="text-sm">{selectedConsulta.fechaAsignacion}</div>
                </div>
              </div>

              {/* Información del Cliente */}
              <div>
                <h4 className="mb-3">Información del Cliente</h4>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label>Nombre</Label>
                    <div className="mt-1 p-2 bg-gray-50 rounded">{selectedConsulta.nombre}</div>
                  </div>
                  <div>
                    <Label>Email</Label>
                    <div className="mt-1 p-2 bg-gray-50 rounded">{selectedConsulta.email}</div>
                  </div>
                  <div>
                    <Label>Tipo</Label>
                    <div className="mt-1">{getTipoBadge(selectedConsulta.tipo)}</div>
                  </div>
                  <div>
                    <Label>Fecha Recepción</Label>
                    <div className="mt-1 p-2 bg-gray-50 rounded">{selectedConsulta.fecha}</div>
                  </div>
                </div>
              </div>

              <div>
                <Label>Asunto</Label>
                <div className="mt-1 p-3 bg-gray-50 rounded">{selectedConsulta.asunto}</div>
              </div>

              <div>
                <Label>Mensaje</Label>
                <div className="mt-1 p-3 bg-gray-50 rounded whitespace-pre-wrap">
                  {selectedConsulta.mensaje}
                </div>
              </div>

              {/* Gestión de Estado */}
              <div>
                <Label>Actualizar Estado</Label>
                <div className="mt-2 flex gap-2">
                  <Button
                    variant={selectedConsulta.estado === "pendiente" ? "default" : "outline"}
                    onClick={() => handleEstadoChange("pendiente")}
                    className="flex-1"
                  >
                    <Clock className="w-4 h-4 mr-2" />
                    Pendiente
                  </Button>
                  <Button
                    variant={selectedConsulta.estado === "en_proceso" ? "default" : "outline"}
                    onClick={() => handleEstadoChange("en_proceso")}
                    className="flex-1"
                  >
                    <AlertCircle className="w-4 h-4 mr-2" />
                    En Proceso
                  </Button>
                  <Button
                    variant={selectedConsulta.estado === "completada" ? "default" : "outline"}
                    onClick={() => handleEstadoChange("completada")}
                    className="flex-1"
                  >
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Completada
                  </Button>
                </div>
              </div>

              {/* Notas de Seguimiento */}
              <div>
                <Label>Notas de Seguimiento</Label>
                <div className="mt-2 space-y-2 max-h-48 overflow-y-auto">
                  {selectedConsulta.notas.length === 0 ? (
                    <div className="text-sm text-gray-500 italic p-3 bg-gray-50 rounded">
                      No hay notas de seguimiento aún
                    </div>
                  ) : (
                    selectedConsulta.notas.map((nota, idx) => (
                      <div key={idx} className="p-3 bg-blue-50 border-l-4 border-blue-400 rounded text-sm">
                        {nota}
                      </div>
                    ))
                  )}
                </div>
                <div className="mt-3 space-y-2">
                  <Textarea
                    placeholder="Añadir nota de seguimiento... (ej: Cliente contactado por teléfono, Enviada propuesta, etc.)"
                    value={nuevaNota}
                    onChange={(e) => setNuevaNota(e.target.value)}
                    rows={3}
                  />
                  <Button onClick={handleAddNota} disabled={!nuevaNota.trim()}>
                    Añadir Nota
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
