import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { 
  MessageSquare, 
  Clock,
  CheckCircle2,
  AlertCircle,
  TrendingUp
} from "lucide-react";

interface OperadorDashboardProps {
  onNavigate: (view: string) => void;
  userName: string;
}

// Datos mock - en producción esto vendría filtrado por el operador logueado
const mockStats = {
  misConsultasTotal: 15,
  pendientes: 5,
  enProceso: 8,
  completadas: 2,
  completadasMes: 12,
  tiempoPromedio: "2.5 horas"
};

const recentActivities = [
  { id: 1, cliente: "Juan Pérez", accion: "Consulta asignada", estado: "pendiente", time: "Hace 5 min" },
  { id: 2, cliente: "María García", accion: "Estado actualizado", estado: "en_proceso", time: "Hace 1 hora" },
  { id: 3, cliente: "Carlos López", accion: "Nota añadida", estado: "en_proceso", time: "Hace 2 horas" },
  { id: 4, cliente: "Ana Martínez", accion: "Consulta completada", estado: "completada", time: "Hace 3 horas" },
  { id: 5, cliente: "Roberto Díaz", accion: "Consulta asignada", estado: "pendiente", time: "Hace 4 horas" }
];

const consultasPrioritarias = [
  { id: 1, cliente: "Juan Pérez", asunto: "Consultoría Estratégica", tiempo: "3 días sin respuesta", prioridad: "alta" },
  { id: 2, cliente: "Laura Sánchez", asunto: "Transformación Digital", tiempo: "1 día sin respuesta", prioridad: "media" },
  { id: 3, cliente: "Pedro Ramírez", asunto: "Gestión de Equipos", tiempo: "4 horas sin respuesta", prioridad: "baja" }
];

export function OperadorDashboard({ onNavigate, userName }: OperadorDashboardProps) {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl mb-2">Mi Panel de Trabajo</h1>
        <p className="text-gray-600">Bienvenido, {userName}. Aquí está el resumen de tus consultas asignadas.</p>
      </div>

      {/* Estadísticas del Operador */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <MessageSquare className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-2xl">{mockStats.misConsultasTotal}</span>
          </div>
          <div className="mb-1">Mis Consultas</div>
          <div className="text-sm text-gray-600">Total asignadas</div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <Clock className="w-6 h-6 text-orange-600" />
            </div>
            <span className="text-2xl">{mockStats.pendientes}</span>
          </div>
          <div className="mb-1">Pendientes</div>
          <div className="text-sm text-gray-600">Requieren atención</div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <AlertCircle className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-2xl">{mockStats.enProceso}</span>
          </div>
          <div className="mb-1">En Proceso</div>
          <div className="text-sm text-gray-600">En seguimiento</div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6 text-green-600" />
            </div>
            <span className="text-2xl">{mockStats.completadas}</span>
          </div>
          <div className="mb-1">Completadas Hoy</div>
          <div className="text-sm text-gray-600">{mockStats.completadasMes} este mes</div>
        </Card>
      </div>

      {/* Rendimiento */}
      <Card className="p-6">
        <h3 className="text-lg mb-4">Tu Rendimiento</h3>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <div className="text-2xl">{mockStats.completadasMes}</div>
              <div className="text-sm text-gray-600">Completadas este mes</div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Clock className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <div className="text-2xl">{mockStats.tiempoPromedio}</div>
              <div className="text-sm text-gray-600">Tiempo promedio respuesta</div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <div className="text-2xl">95%</div>
              <div className="text-sm text-gray-600">Tasa de resolución</div>
            </div>
          </div>
        </div>
      </Card>

      {/* Consultas Prioritarias */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg">Consultas Prioritarias</h3>
          <Button variant="outline" size="sm" onClick={() => onNavigate("mis-consultas")}>
            Ver Todas
          </Button>
        </div>
        <div className="space-y-3">
          {consultasPrioritarias.map((consulta) => (
            <div 
              key={consulta.id} 
              className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 cursor-pointer"
              onClick={() => onNavigate("mis-consultas")}
            >
              <div className="flex items-center gap-4">
                <div className={`w-3 h-3 rounded-full ${
                  consulta.prioridad === "alta" ? "bg-red-500" :
                  consulta.prioridad === "media" ? "bg-yellow-500" :
                  "bg-green-500"
                }`} />
                <div>
                  <div>{consulta.cliente}</div>
                  <div className="text-sm text-gray-600">{consulta.asunto}</div>
                </div>
              </div>
              <div className="text-sm text-gray-500">{consulta.tiempo}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* Actividad Reciente */}
      <Card className="p-6">
        <h3 className="text-lg mb-4">Mi Actividad Reciente</h3>
        <div className="space-y-4">
          {recentActivities.map((activity) => (
            <div key={activity.id} className="flex items-start gap-4 pb-4 border-b last:border-b-0 last:pb-0">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                activity.estado === "pendiente" ? "bg-orange-100" :
                activity.estado === "en_proceso" ? "bg-blue-100" :
                "bg-green-100"
              }`}>
                {activity.estado === "pendiente" ? (
                  <Clock className="w-5 h-5 text-orange-600" />
                ) : activity.estado === "en_proceso" ? (
                  <AlertCircle className="w-5 h-5 text-blue-600" />
                ) : (
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                )}
              </div>
              <div className="flex-1">
                <div>{activity.accion}</div>
                <div className="text-sm text-gray-600">{activity.cliente}</div>
              </div>
              <div className="text-sm text-gray-500">{activity.time}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* Acceso Rápido */}
      <Card className="p-6">
        <h3 className="text-lg mb-4">Acceso Rápido</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <Button 
            variant="outline" 
            className="justify-start gap-2 h-auto p-4"
            onClick={() => onNavigate("mis-consultas")}
          >
            <MessageSquare className="w-5 h-5" />
            <div className="text-left">
              <div>Mis Consultas</div>
              <div className="text-xs text-gray-600">Ver y gestionar consultas asignadas</div>
            </div>
          </Button>
          <Button 
            variant="outline" 
            className="justify-start gap-2 h-auto p-4"
            onClick={() => onNavigate("testimonios")}
          >
            <CheckCircle2 className="w-5 h-5" />
            <div className="text-left">
              <div>Testimonios</div>
              <div className="text-xs text-gray-600">Ver testimonios de clientes</div>
            </div>
          </Button>
        </div>
      </Card>
    </div>
  );
}
