import { useState } from "react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { Badge } from "../ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "../ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "../ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "../ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import { Search, Eye, Filter, Trash2, CheckCircle2, AlertCircle } from "lucide-react";
import { toast } from "sonner@2.0.3";

// Datos mock
const mockConsultas = [
  {
    id: 1,
    nombre: "Juan Pérez",
    email: "juan@email.com",
    tipo: "consulta",
    asunto: "Consultoría Estratégica",
    mensaje: "Me gustaría saber más sobre sus servicios de consultoría...",
    estado: "pendiente",
    fecha: "2024-11-03",
    asignadoA: null,
    notas: []
  },
  {
    id: 2,
    nombre: "María García",
    email: "maria@email.com",
    tipo: "sugerencia",
    asunto: "Mejora en servicio",
    mensaje: "Sería genial si pudieran ofrecer...",
    estado: "en_proceso",
    fecha: "2024-11-02",
    asignadoA: "Operador 1",
    notas: ["Cliente interesado en servicios premium"]
  },
  {
    id: 3,
    nombre: "Carlos López",
    email: "carlos@email.com",
    tipo: "consulta",
    asunto: "Transformación Digital",
    mensaje: "Necesito ayuda para digitalizar mi empresa...",
    estado: "completada",
    fecha: "2024-11-01",
    asignadoA: "Admin",
    notas: ["Convertido a lead", "Propuesta enviada"]
  },
  {
    id: 4,
    nombre: "Ana Martínez",
    email: "ana@email.com",
    tipo: "otro",
    asunto: "Información general",
    mensaje: "¿Tienen oficinas en mi ciudad?",
    estado: "pendiente",
    fecha: "2024-11-03",
    asignadoA: null,
    notas: []
  }
];

const usuarios = ["Admin", "Operador 1", "Operador 2"];

export function ConsultasManager() {
  const [consultas, setConsultas] = useState(mockConsultas);
  const [selectedConsulta, setSelectedConsulta] = useState<typeof mockConsultas[0] | null>(null);
  const [filterEstado, setFilterEstado] = useState("todos");
  const [filterTipo, setFilterTipo] = useState("todos");
  const [searchTerm, setSearchTerm] = useState("");
  const [nuevaNota, setNuevaNota] = useState("");
  const [consultaToDelete, setConsultaToDelete] = useState<number | null>(null);

  const filteredConsultas = consultas.filter(c => {
    const matchEstado = filterEstado === "todos" || c.estado === filterEstado;
    const matchTipo = filterTipo === "todos" || c.tipo === filterTipo;
    const matchSearch = c.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       c.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       c.asunto.toLowerCase().includes(searchTerm.toLowerCase());
    return matchEstado && matchTipo && matchSearch;
  });

  const handleEstadoChange = (newEstado: string) => {
    if (selectedConsulta) {
      setConsultas(consultas.map(c => 
        c.id === selectedConsulta.id ? { ...c, estado: newEstado } : c
      ));
      setSelectedConsulta({ ...selectedConsulta, estado: newEstado });
      toast.success("Estado actualizado correctamente", {
        description: `La consulta #${selectedConsulta.id} ahora está en estado: ${newEstado}`,
        icon: <CheckCircle2 className="w-5 h-5" />
      });
    }
  };

  const handleAsignarUsuario = (usuario: string) => {
    if (selectedConsulta) {
      setConsultas(consultas.map(c => 
        c.id === selectedConsulta.id ? { ...c, asignadoA: usuario } : c
      ));
      setSelectedConsulta({ ...selectedConsulta, asignadoA: usuario });
      toast.success(`Consulta asignada a ${usuario}`, {
        description: `${usuario} ahora tiene acceso a esta consulta`,
        icon: <CheckCircle2 className="w-5 h-5" />
      });
    }
  };

  const handleAddNota = () => {
    if (!selectedConsulta) return;
    
    if (!nuevaNota.trim()) {
      toast.error("La nota no puede estar vacía", {
        icon: <AlertCircle className="w-5 h-5" />
      });
      return;
    }

    const fechaHora = new Date().toLocaleString('es-ES', { 
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    const notaConFecha = `[${fechaHora}] ${nuevaNota}`;
    const updatedNotas = [...selectedConsulta.notas, notaConFecha];
    setConsultas(consultas.map(c => 
      c.id === selectedConsulta.id ? { ...c, notas: updatedNotas } : c
    ));
    setSelectedConsulta({ ...selectedConsulta, notas: updatedNotas });
    setNuevaNota("");
    toast.success("Nota añadida correctamente", {
      icon: <CheckCircle2 className="w-5 h-5" />
    });
  };

  const handleDeleteConsulta = () => {
    if (consultaToDelete) {
      setConsultas(consultas.filter(c => c.id !== consultaToDelete));
      toast.success("Consulta eliminada", {
        description: "La consulta ha sido eliminada permanentemente",
        icon: <CheckCircle2 className="w-5 h-5" />
      });
      setConsultaToDelete(null);
      if (selectedConsulta?.id === consultaToDelete) {
        setSelectedConsulta(null);
      }
    }
  };

  const getEstadoBadge = (estado: string) => {
    const variants: Record<string, { variant: "default" | "secondary" | "destructive" | "outline", label: string }> = {
      pendiente: { variant: "outline", label: "Pendiente" },
      en_proceso: { variant: "default", label: "En Proceso" },
      completada: { variant: "secondary", label: "Completada" }
    };
    const config = variants[estado] || variants.pendiente;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const getTipoBadge = (tipo: string) => {
    const colors: Record<string, string> = {
      consulta: "bg-blue-100 text-blue-700",
      sugerencia: "bg-green-100 text-green-700",
      otro: "bg-gray-100 text-gray-700"
    };
    return (
      <Badge variant="outline" className={colors[tipo]}>
        {tipo.charAt(0).toUpperCase() + tipo.slice(1)}
      </Badge>
    );
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl mb-2">Gestión de Consultas</h1>
        <p className="text-gray-600">Administra todas las interacciones y consultas recibidas</p>
      </div>

      {/* Filtros */}
      <Card className="p-6">
        <div className="grid md:grid-cols-4 gap-4">
          <div>
            <Label>Buscar</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Nombre, email, asunto..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          <div>
            <Label>Estado</Label>
            <Select value={filterEstado} onValueChange={setFilterEstado}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                <SelectItem value="pendiente">Pendiente</SelectItem>
                <SelectItem value="en_proceso">En Proceso</SelectItem>
                <SelectItem value="completada">Completada</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Tipo</Label>
            <Select value={filterTipo} onValueChange={setFilterTipo}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                <SelectItem value="consulta">Consulta</SelectItem>
                <SelectItem value="sugerencia">Sugerencia</SelectItem>
                <SelectItem value="otro">Otro</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-end">
            <Button variant="outline" className="w-full gap-2">
              <Filter className="w-4 h-4" />
              Aplicar Filtros
            </Button>
          </div>
        </div>
      </Card>

      {/* Tabla de Consultas */}
      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nombre</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Asunto</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead>Fecha</TableHead>
              <TableHead>Asignado</TableHead>
              <TableHead>Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredConsultas.map((consulta) => (
              <TableRow key={consulta.id}>
                <TableCell>{consulta.nombre}</TableCell>
                <TableCell className="text-sm text-gray-600">{consulta.email}</TableCell>
                <TableCell>{getTipoBadge(consulta.tipo)}</TableCell>
                <TableCell className="max-w-xs truncate">{consulta.asunto}</TableCell>
                <TableCell>{getEstadoBadge(consulta.estado)}</TableCell>
                <TableCell className="text-sm">{consulta.fecha}</TableCell>
                <TableCell className="text-sm">{consulta.asignadoA || "Sin asignar"}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSelectedConsulta(consulta)}
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setConsultaToDelete(consulta.id)}
                    >
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      {/* Dialog de Detalle */}
      <Dialog open={!!selectedConsulta} onOpenChange={() => setSelectedConsulta(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detalle de Consulta #{selectedConsulta?.id}</DialogTitle>
            <DialogDescription>
              Gestiona el estado y seguimiento de esta consulta
            </DialogDescription>
          </DialogHeader>

          {selectedConsulta && (
            <div className="space-y-6">
              {/* Información del Cliente */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>Nombre</Label>
                  <div className="mt-1 p-2 bg-gray-50 rounded">{selectedConsulta.nombre}</div>
                </div>
                <div>
                  <Label>Email</Label>
                  <div className="mt-1 p-2 bg-gray-50 rounded">{selectedConsulta.email}</div>
                </div>
                <div>
                  <Label>Tipo</Label>
                  <div className="mt-1">{getTipoBadge(selectedConsulta.tipo)}</div>
                </div>
                <div>
                  <Label>Fecha</Label>
                  <div className="mt-1 p-2 bg-gray-50 rounded">{selectedConsulta.fecha}</div>
                </div>
              </div>

              <div>
                <Label>Asunto</Label>
                <div className="mt-1 p-2 bg-gray-50 rounded">{selectedConsulta.asunto}</div>
              </div>

              <div>
                <Label>Mensaje</Label>
                <div className="mt-1 p-3 bg-gray-50 rounded">{selectedConsulta.mensaje}</div>
              </div>

              {/* Gestión */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>Cambiar Estado</Label>
                  <Select value={selectedConsulta.estado} onValueChange={handleEstadoChange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pendiente">Pendiente</SelectItem>
                      <SelectItem value="en_proceso">En Proceso</SelectItem>
                      <SelectItem value="completada">Completada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Asignar a Usuario</Label>
                  <Select 
                    value={selectedConsulta.asignadoA || ""} 
                    onValueChange={handleAsignarUsuario}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar usuario" />
                    </SelectTrigger>
                    <SelectContent>
                      {usuarios.map((usuario) => (
                        <SelectItem key={usuario} value={usuario}>
                          {usuario}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Notas */}
              <div>
                <Label>Notas y Seguimiento</Label>
                <div className="mt-2 space-y-2">
                  {selectedConsulta.notas.map((nota, idx) => (
                    <div key={idx} className="p-3 bg-blue-50 rounded text-sm">
                      {nota}
                    </div>
                  ))}
                  {selectedConsulta.notas.length === 0 && (
                    <div className="text-sm text-gray-500 italic">No hay notas aún</div>
                  )}
                </div>
                <div className="mt-2 flex gap-2">
                  <Textarea
                    placeholder="Añadir nota..."
                    value={nuevaNota}
                    onChange={(e) => setNuevaNota(e.target.value)}
                    rows={2}
                  />
                  <Button onClick={handleAddNota}>Añadir</Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Alert Dialog de Confirmación de Eliminación */}
      <AlertDialog open={!!consultaToDelete} onOpenChange={() => setConsultaToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción eliminará permanentemente la consulta #{consultaToDelete}.
              Esta operación no se puede deshacer.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConsulta} className="bg-red-600 hover:bg-red-700">
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
