import { useState } from "react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Badge } from "../ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "../ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "../ui/alert-dialog";
import { Search, Eye, Edit, Trash2, Plus, Shield, User, CheckCircle2, AlertCircle, XCircle } from "lucide-react";
import { toast } from "sonner@2.0.3";

// Datos mock
const mockUsuarios = [
  {
    id: 1,
    nombre: "Admin Principal",
    email: "admin@negocio.com",
    rol: "admin",
    estado: "activo",
    fechaCreacion: "2024-01-15",
    ultimoAcceso: "2024-11-03"
  },
  {
    id: 2,
    nombre: "Operador 1",
    email: "operador@negocio.com",
    rol: "operador",
    estado: "activo",
    fechaCreacion: "2024-02-20",
    ultimoAcceso: "2024-11-03"
  },
  {
    id: 3,
    nombre: "Operador 2",
    email: "operador2@negocio.com",
    rol: "operador",
    estado: "activo",
    fechaCreacion: "2024-03-10",
    ultimoAcceso: "2024-11-02"
  },
  {
    id: 4,
    nombre: "Usuario Inactivo",
    email: "inactivo@negocio.com",
    rol: "operador",
    estado: "inactivo",
    fechaCreacion: "2024-01-05",
    ultimoAcceso: "2024-08-15"
  }
];

export function UsuariosManager() {
  const [usuarios, setUsuarios] = useState(mockUsuarios);
  const [selectedUsuario, setSelectedUsuario] = useState<typeof mockUsuarios[0] | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [form, setForm] = useState({
    nombre: "",
    email: "",
    rol: "operador",
    estado: "activo",
    password: ""
  });

  const filteredUsuarios = usuarios.filter(u => {
    const matchSearch = u.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       u.email.toLowerCase().includes(searchTerm.toLowerCase());
    return matchSearch;
  });

  const validateForm = (): boolean => {
    if (!form.nombre.trim()) {
      toast.error("El nombre es obligatorio", {
        icon: <AlertCircle className="w-5 h-5" />
      });
      return false;
    }

    if (!form.email.trim()) {
      toast.error("El correo electrónico es obligatorio", {
        icon: <AlertCircle className="w-5 h-5" />
      });
      return false;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      toast.error("Por favor ingresa un correo electrónico válido", {
        icon: <AlertCircle className="w-5 h-5" />
      });
      return false;
    }

    // Verificar email duplicado
    const emailExists = usuarios.some(u => 
      u.email === form.email && u.id !== selectedUsuario?.id
    );
    if (emailExists) {
      toast.error("Ya existe un usuario con este correo electrónico", {
        icon: <AlertCircle className="w-5 h-5" />
      });
      return false;
    }

    if (isCreating && form.password.length < 6) {
      toast.error("La contraseña debe tener al menos 6 caracteres", {
        icon: <AlertCircle className="w-5 h-5" />
      });
      return false;
    }

    return true;
  };

  const handleCreate = () => {
    if (!validateForm()) return;

    const newUsuario = {
      id: Math.max(...usuarios.map(u => u.id)) + 1,
      nombre: form.nombre,
      email: form.email,
      rol: form.rol,
      estado: form.estado,
      fechaCreacion: new Date().toISOString().split('T')[0],
      ultimoAcceso: "-"
    };
    setUsuarios([...usuarios, newUsuario]);
    toast.success("Usuario creado exitosamente", {
      description: `${form.nombre} (${form.rol}) ha sido añadido al sistema`,
      icon: <CheckCircle2 className="w-5 h-5" />
    });
    setIsCreating(false);
    resetForm();
  };

  const handleEdit = () => {
    if (!selectedUsuario) return;
    if (!validateForm()) return;

    const oldData = selectedUsuario;
    setUsuarios(usuarios.map(u => 
      u.id === selectedUsuario.id 
        ? { ...u, nombre: form.nombre, email: form.email, rol: form.rol, estado: form.estado }
        : u
    ));

    let changes = [];
    if (oldData.rol !== form.rol) {
      changes.push(`rol cambiado a ${form.rol}`);
    }
    if (oldData.estado !== form.estado) {
      changes.push(`estado cambiado a ${form.estado}`);
    }

    toast.success("Usuario actualizado exitosamente", {
      description: changes.length > 0 ? changes.join(", ") : "Información actualizada",
      icon: <CheckCircle2 className="w-5 h-5" />
    });
    setIsEditing(false);
    setSelectedUsuario(null);
    resetForm();
  };

  const handleDelete = () => {
    if (deleteId) {
      const usuario = usuarios.find(u => u.id === deleteId);
      
      // Verificar que no sea el último admin
      if (usuario?.rol === "admin") {
        const adminCount = usuarios.filter(u => u.rol === "admin" && u.id !== deleteId).length;
        if (adminCount === 0) {
          toast.error("No se puede eliminar el último administrador", {
            description: "Debe haber al menos un administrador en el sistema",
            icon: <XCircle className="w-5 h-5" />
          });
          setDeleteId(null);
          return;
        }
      }

      setUsuarios(usuarios.filter(u => u.id !== deleteId));
      toast.success("Usuario eliminado exitosamente", {
        description: `${usuario?.nombre} ha sido eliminado del sistema`,
        icon: <CheckCircle2 className="w-5 h-5" />
      });
      setDeleteId(null);
      setSelectedUsuario(null);
    }
  };

  const resetForm = () => {
    setForm({
      nombre: "",
      email: "",
      rol: "operador",
      estado: "activo",
      password: ""
    });
  };

  const openCreateDialog = () => {
    resetForm();
    setIsCreating(true);
  };

  const openEditDialog = (usuario: typeof mockUsuarios[0]) => {
    setForm({
      nombre: usuario.nombre,
      email: usuario.email,
      rol: usuario.rol,
      estado: usuario.estado,
      password: ""
    });
    setIsEditing(true);
  };

  const getRolBadge = (rol: string) => {
    if (rol === "admin") {
      return (
        <Badge className="bg-purple-100 text-purple-700 hover:bg-purple-100">
          <Shield className="w-3 h-3 mr-1" />
          Administrador
        </Badge>
      );
    }
    return (
      <Badge variant="outline">
        <User className="w-3 h-3 mr-1" />
        Operador
      </Badge>
    );
  };

  const getEstadoBadge = (estado: string) => {
    return estado === "activo" ? (
      <Badge variant="default">Activo</Badge>
    ) : (
      <Badge variant="secondary">Inactivo</Badge>
    );
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl mb-2">Gestión de Usuarios</h1>
          <p className="text-gray-600">Administra usuarios y asigna roles del sistema</p>
        </div>
        <Button onClick={openCreateDialog} className="gap-2">
          <Plus className="w-4 h-4" />
          Nuevo Usuario
        </Button>
      </div>

      {/* Búsqueda */}
      <Card className="p-6">
        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <Label>Buscar</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Nombre, email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
          <div className="md:col-span-2 flex items-end">
            <div className="text-sm text-gray-600">
              Total de usuarios: {filteredUsuarios.length} | 
              Activos: {usuarios.filter(u => u.estado === "activo").length}
            </div>
          </div>
        </div>
      </Card>

      {/* Tabla de Usuarios */}
      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nombre</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Rol</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead>Fecha Creación</TableHead>
              <TableHead>Último Acceso</TableHead>
              <TableHead>Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredUsuarios.map((usuario) => (
              <TableRow key={usuario.id}>
                <TableCell>{usuario.nombre}</TableCell>
                <TableCell className="text-sm text-gray-600">{usuario.email}</TableCell>
                <TableCell>{getRolBadge(usuario.rol)}</TableCell>
                <TableCell>{getEstadoBadge(usuario.estado)}</TableCell>
                <TableCell className="text-sm">{usuario.fechaCreacion}</TableCell>
                <TableCell className="text-sm text-gray-600">{usuario.ultimoAcceso}</TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSelectedUsuario(usuario)}
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setSelectedUsuario(usuario);
                        openEditDialog(usuario);
                      }}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setDeleteId(usuario.id)}
                      disabled={usuario.rol === "admin" && usuario.id === 1}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      {/* Dialog de Detalle */}
      <Dialog open={!!selectedUsuario && !isEditing} onOpenChange={() => setSelectedUsuario(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Detalle de Usuario</DialogTitle>
            <DialogDescription>Información completa del usuario</DialogDescription>
          </DialogHeader>

          {selectedUsuario && (
            <div className="space-y-4">
              <div>
                <Label>Nombre</Label>
                <div className="mt-1 p-2 bg-gray-50 rounded">{selectedUsuario.nombre}</div>
              </div>
              <div>
                <Label>Email</Label>
                <div className="mt-1 p-2 bg-gray-50 rounded">{selectedUsuario.email}</div>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>Rol</Label>
                  <div className="mt-1">{getRolBadge(selectedUsuario.rol)}</div>
                </div>
                <div>
                  <Label>Estado</Label>
                  <div className="mt-1">{getEstadoBadge(selectedUsuario.estado)}</div>
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>Fecha de Creación</Label>
                  <div className="mt-1 p-2 bg-gray-50 rounded">{selectedUsuario.fechaCreacion}</div>
                </div>
                <div>
                  <Label>Último Acceso</Label>
                  <div className="mt-1 p-2 bg-gray-50 rounded">{selectedUsuario.ultimoAcceso}</div>
                </div>
              </div>
              <div className="flex gap-2 pt-4">
                <Button onClick={() => openEditDialog(selectedUsuario)}>
                  <Edit className="w-4 h-4 mr-2" />
                  Editar
                </Button>
                <Button 
                  variant="destructive" 
                  onClick={() => setDeleteId(selectedUsuario.id)}
                  disabled={selectedUsuario.rol === "admin" && selectedUsuario.id === 1}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Eliminar
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Dialog de Crear/Editar */}
      <Dialog open={isCreating || isEditing} onOpenChange={(open) => {
        if (!open) {
          setIsCreating(false);
          setIsEditing(false);
          setSelectedUsuario(null);
          resetForm();
        }
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{isCreating ? "Crear Nuevo Usuario" : "Editar Usuario"}</DialogTitle>
            <DialogDescription>
              {isCreating ? "Completa los datos para crear un nuevo usuario" : "Modifica los datos del usuario"}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label>Nombre Completo *</Label>
              <Input
                value={form.nombre}
                onChange={(e) => setForm({ ...form, nombre: e.target.value })}
                placeholder="Juan Pérez"
              />
            </div>

            <div>
              <Label>Email *</Label>
              <Input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="usuario@email.com"
              />
            </div>

            {isCreating && (
              <div>
                <Label>Contraseña *</Label>
                <Input
                  type="password"
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  placeholder="••••••••"
                />
              </div>
            )}

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Rol *</Label>
                <Select value={form.rol} onValueChange={(value) => setForm({ ...form, rol: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Administrador</SelectItem>
                    <SelectItem value="operador">Operador</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Estado *</Label>
                <Select value={form.estado} onValueChange={(value) => setForm({ ...form, estado: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="activo">Activo</SelectItem>
                    <SelectItem value="inactivo">Inactivo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex gap-2 pt-4">
              <Button onClick={isCreating ? handleCreate : handleEdit}>
                {isCreating ? "Crear Usuario" : "Guardar Cambios"}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  setIsCreating(false);
                  setIsEditing(false);
                  setSelectedUsuario(null);
                  resetForm();
                }}
              >
                Cancelar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Alert Dialog para Eliminar */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. El usuario será eliminado permanentemente del sistema.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
