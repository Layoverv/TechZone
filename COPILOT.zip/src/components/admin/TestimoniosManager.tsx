import { useState } from "react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { Badge } from "../ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "../ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../ui/table";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "../ui/alert-dialog";
import { Search, Eye, Check, X, Edit, Trash2, Star, CheckCircle2, AlertCircle, XCircle } from "lucide-react";
import { toast } from "sonner@2.0.3";

// Datos mock
const mockTestimonios = [
  {
    id: 1,
    nombre: "Juan Pérez",
    cargo: "CEO, TechStart",
    mensaje: "Excelente servicio, superaron todas mis expectativas.",
    rating: 5,
    fecha: "2024-11-03",
    estado: "pendiente",
    isAnonymous: false
  },
  {
    id: 2,
    nombre: "Anónimo",
    cargo: "Cliente",
    mensaje: "Muy satisfecho con los resultados obtenidos.",
    rating: 4,
    fecha: "2024-11-02",
    estado: "aprobado",
    isAnonymous: true
  },
  {
    id: 3,
    nombre: "María González",
    cargo: "Directora, Innovación SA",
    mensaje: "Profesionales de primer nivel, altamente recomendados.",
    rating: 5,
    fecha: "2024-11-01",
    estado: "aprobado",
    isAnonymous: false
  },
  {
    id: 4,
    nombre: "Carlos López",
    cargo: "Gerente, Desarrollo Plus",
    mensaje: "Buenos servicios pero podrían mejorar en tiempos de respuesta.",
    rating: 3,
    fecha: "2024-10-30",
    estado: "rechazado",
    isAnonymous: false
  }
];

export function TestimoniosManager() {
  const [testimonios, setTestimonios] = useState(mockTestimonios);
  const [selectedTestimonio, setSelectedTestimonio] = useState<typeof mockTestimonios[0] | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [filterEstado, setFilterEstado] = useState("todos");
  const [searchTerm, setSearchTerm] = useState("");
  const [editForm, setEditForm] = useState({
    nombre: "",
    cargo: "",
    mensaje: "",
    rating: 5
  });

  const filteredTestimonios = testimonios.filter(t => {
    const matchEstado = filterEstado === "todos" || t.estado === filterEstado;
    const matchSearch = t.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       t.mensaje.toLowerCase().includes(searchTerm.toLowerCase());
    return matchEstado && matchSearch;
  });

  const handleAprobar = (id: number) => {
    const testimonio = testimonios.find(t => t.id === id);
    setTestimonios(testimonios.map(t => 
      t.id === id ? { ...t, estado: "aprobado" } : t
    ));
    toast.success("Testimonio aprobado", {
      description: `El testimonio de ${testimonio?.nombre} ahora es visible públicamente`,
      icon: <CheckCircle2 className="w-5 h-5" />
    });
    setSelectedTestimonio(null);
  };

  const handleRechazar = (id: number) => {
    const testimonio = testimonios.find(t => t.id === id);
    setTestimonios(testimonios.map(t => 
      t.id === id ? { ...t, estado: "rechazado" } : t
    ));
    toast.warning("Testimonio rechazado", {
      description: `El testimonio de ${testimonio?.nombre} ha sido rechazado`,
      icon: <XCircle className="w-5 h-5" />
    });
    setSelectedTestimonio(null);
  };

  const handleEdit = () => {
    if (!selectedTestimonio) return;

    if (!editForm.nombre.trim()) {
      toast.error("El nombre es obligatorio", {
        icon: <AlertCircle className="w-5 h-5" />
      });
      return;
    }

    if (!editForm.mensaje.trim()) {
      toast.error("El mensaje es obligatorio", {
        icon: <AlertCircle className="w-5 h-5" />
      });
      return;
    }

    if (editForm.mensaje.trim().length < 10) {
      toast.error("El mensaje debe tener al menos 10 caracteres", {
        icon: <AlertCircle className="w-5 h-5" />
      });
      return;
    }

    setTestimonios(testimonios.map(t => 
      t.id === selectedTestimonio.id 
        ? { ...t, ...editForm }
        : t
    ));
    toast.success("Testimonio actualizado", {
      description: "Los cambios se han guardado correctamente",
      icon: <CheckCircle2 className="w-5 h-5" />
    });
    setIsEditing(false);
    setSelectedTestimonio(null);
  };

  const handleDelete = () => {
    if (deleteId) {
      const testimonio = testimonios.find(t => t.id === deleteId);
      setTestimonios(testimonios.filter(t => t.id !== deleteId));
      toast.success("Testimonio eliminado", {
        description: `El testimonio de ${testimonio?.nombre} ha sido eliminado permanentemente`,
        icon: <CheckCircle2 className="w-5 h-5" />
      });
      setDeleteId(null);
      setSelectedTestimonio(null);
    }
  };

  const openEditMode = (testimonio: typeof mockTestimonios[0]) => {
    setEditForm({
      nombre: testimonio.nombre,
      cargo: testimonio.cargo,
      mensaje: testimonio.mensaje,
      rating: testimonio.rating
    });
    setIsEditing(true);
  };

  const getEstadoBadge = (estado: string) => {
    const variants: Record<string, { variant: "default" | "secondary" | "destructive" | "outline", label: string }> = {
      pendiente: { variant: "outline", label: "Pendiente" },
      aprobado: { variant: "default", label: "Aprobado" },
      rechazado: { variant: "destructive", label: "Rechazado" }
    };
    const config = variants[estado] || variants.pendiente;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl mb-2">Gestión de Testimonios</h1>
        <p className="text-gray-600">Administra, aprueba o rechaza testimonios de clientes</p>
      </div>

      {/* Filtros */}
      <Card className="p-6">
        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <Label>Buscar</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Nombre, mensaje..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          <div>
            <Label>Estado</Label>
            <Select value={filterEstado} onValueChange={setFilterEstado}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos</SelectItem>
                <SelectItem value="pendiente">Pendiente</SelectItem>
                <SelectItem value="aprobado">Aprobado</SelectItem>
                <SelectItem value="rechazado">Rechazado</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-end gap-2">
            <div className="flex-1">
              <div className="text-sm text-gray-600">
                Total: {filteredTestimonios.length} | 
                Pendientes: {testimonios.filter(t => t.estado === "pendiente").length}
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Tabla de Testimonios */}
      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nombre</TableHead>
              <TableHead>Cargo</TableHead>
              <TableHead>Mensaje</TableHead>
              <TableHead>Rating</TableHead>
              <TableHead>Fecha</TableHead>
              <TableHead>Estado</TableHead>
              <TableHead>Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredTestimonios.map((testimonio) => (
              <TableRow key={testimonio.id}>
                <TableCell>
                  {testimonio.isAnonymous ? (
                    <span className="text-gray-500 italic">{testimonio.nombre}</span>
                  ) : (
                    testimonio.nombre
                  )}
                </TableCell>
                <TableCell className="text-sm text-gray-600">{testimonio.cargo}</TableCell>
                <TableCell className="max-w-xs truncate">{testimonio.mensaje}</TableCell>
                <TableCell>
                  <div className="flex gap-0.5">
                    {Array.from({ length: testimonio.rating }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                </TableCell>
                <TableCell className="text-sm">{testimonio.fecha}</TableCell>
                <TableCell>{getEstadoBadge(testimonio.estado)}</TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSelectedTestimonio(testimonio)}
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                    {testimonio.estado === "pendiente" && (
                      <>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleAprobar(testimonio.id)}
                        >
                          <Check className="w-4 h-4 text-green-600" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRechazar(testimonio.id)}
                        >
                          <X className="w-4 h-4 text-red-600" />
                        </Button>
                      </>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      {/* Dialog de Detalle/Edición */}
      <Dialog open={!!selectedTestimonio} onOpenChange={() => {
        setSelectedTestimonio(null);
        setIsEditing(false);
      }}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {isEditing ? "Editar Testimonio" : "Detalle de Testimonio"}
            </DialogTitle>
            <DialogDescription>
              {isEditing ? "Modifica los datos del testimonio" : "Información completa del testimonio"}
            </DialogDescription>
          </DialogHeader>

          {selectedTestimonio && (
            <div className="space-y-4">
              {!isEditing ? (
                <>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label>Nombre</Label>
                      <div className="mt-1 p-2 bg-gray-50 rounded">
                        {selectedTestimonio.isAnonymous ? (
                          <span className="text-gray-500 italic">{selectedTestimonio.nombre}</span>
                        ) : (
                          selectedTestimonio.nombre
                        )}
                      </div>
                    </div>
                    <div>
                      <Label>Cargo</Label>
                      <div className="mt-1 p-2 bg-gray-50 rounded">{selectedTestimonio.cargo}</div>
                    </div>
                  </div>

                  <div>
                    <Label>Mensaje</Label>
                    <div className="mt-1 p-3 bg-gray-50 rounded">{selectedTestimonio.mensaje}</div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label>Calificación</Label>
                      <div className="mt-1 flex gap-1">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star 
                            key={i} 
                            className={`w-5 h-5 ${
                              i < selectedTestimonio.rating 
                                ? "fill-yellow-400 text-yellow-400" 
                                : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <div>
                      <Label>Fecha</Label>
                      <div className="mt-1 p-2 bg-gray-50 rounded">{selectedTestimonio.fecha}</div>
                    </div>
                  </div>

                  <div>
                    <Label>Estado</Label>
                    <div className="mt-1">{getEstadoBadge(selectedTestimonio.estado)}</div>
                  </div>

                  <div className="flex gap-2 pt-4">
                    {!selectedTestimonio.isAnonymous && (
                      <Button 
                        variant="outline" 
                        onClick={() => openEditMode(selectedTestimonio)}
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Editar
                      </Button>
                    )}
                    {selectedTestimonio.estado === "pendiente" && (
                      <>
                        <Button onClick={() => handleAprobar(selectedTestimonio.id)}>
                          <Check className="w-4 h-4 mr-2" />
                          Aprobar
                        </Button>
                        <Button 
                          variant="destructive" 
                          onClick={() => handleRechazar(selectedTestimonio.id)}
                        >
                          <X className="w-4 h-4 mr-2" />
                          Rechazar
                        </Button>
                      </>
                    )}
                    <Button 
                      variant="destructive" 
                      onClick={() => setDeleteId(selectedTestimonio.id)}
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Eliminar
                    </Button>
                  </div>
                </>
              ) : (
                <>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label>Nombre</Label>
                      <Input
                        value={editForm.nombre}
                        onChange={(e) => setEditForm({ ...editForm, nombre: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label>Cargo</Label>
                      <Input
                        value={editForm.cargo}
                        onChange={(e) => setEditForm({ ...editForm, cargo: e.target.value })}
                      />
                    </div>
                  </div>

                  <div>
                    <Label>Mensaje</Label>
                    <Textarea
                      value={editForm.mensaje}
                      onChange={(e) => setEditForm({ ...editForm, mensaje: e.target.value })}
                      rows={4}
                    />
                  </div>

                  <div>
                    <Label>Calificación</Label>
                    <div className="flex gap-2 mt-2">
                      {[1, 2, 3, 4, 5].map((rating) => (
                        <button
                          key={rating}
                          type="button"
                          onClick={() => setEditForm({ ...editForm, rating })}
                        >
                          <Star 
                            className={`w-8 h-8 ${
                              rating <= editForm.rating 
                                ? "fill-yellow-400 text-yellow-400" 
                                : "text-gray-300"
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2 pt-4">
                    <Button onClick={handleEdit}>
                      Guardar Cambios
                    </Button>
                    <Button variant="outline" onClick={() => setIsEditing(false)}>
                      Cancelar
                    </Button>
                  </div>
                </>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Alert Dialog para Eliminar */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. El testimonio será eliminado permanentemente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
