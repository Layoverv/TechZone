import { useState } from "react";
import { Card } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { LogIn } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface LoginProps {
  onLogin: (user: { email: string; role: string; name: string }) => void;
}

export function Login({ onLogin }: LoginProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email.trim() || !password.trim()) {
      toast.error("Por favor completa todos los campos");
      return;
    }

    // Simulación de login
    if (email === "admin@negocio.com" && password === "admin123") {
      toast.success("¡Bienvenido, Administrador!", {
        description: "Accediendo al panel de administración..."
      });
      onLogin({ email, role: "admin", name: "Administrador" });
    } else if (email === "operador@negocio.com" && password === "oper123") {
      toast.success("¡Bienvenido, Operador!", {
        description: "Accediendo a tu panel de trabajo..."
      });
      onLogin({ email, role: "operador", name: "Operador" });
    } else {
      toast.error("Credenciales incorrectas", {
        description: "Verifica tu correo electrónico y contraseña"
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <Card className="w-full max-w-md p-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center mx-auto mb-4">
            <span className="text-white text-2xl">B</span>
          </div>
          <h1 className="text-3xl mb-2">Panel de Administración</h1>
          <p className="text-gray-600">Ingresa tus credenciales para continuar</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="email">Correo Electrónico</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@negocio.com"
              required
            />
          </div>

          <div>
            <Label htmlFor="password">Contraseña</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
            />
          </div>

          <Button type="submit" className="w-full gap-2">
            <LogIn className="w-4 h-4" />
            Iniciar Sesión
          </Button>
        </form>

        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <p className="text-sm mb-2">Credenciales de prueba:</p>
          <p className="text-xs text-gray-600">Admin: admin@negocio.com / admin123</p>
          <p className="text-xs text-gray-600">Operador: operador@negocio.com / oper123</p>
        </div>
      </Card>
    </div>
  );
}
