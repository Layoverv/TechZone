import { Card } from "./ui/card";
import { Briefcase, TrendingUp, Users, Zap } from "lucide-react";

const services = [
  {
    icon: Briefcase,
    title: "Consultoría Estratégica",
    description: "Desarrollamos estrategias personalizadas para optimizar tu negocio y alcanzar tus metas."
  },
  {
    icon: TrendingUp,
    title: "Crecimiento Empresarial",
    description: "Implementamos soluciones que impulsan el crecimiento sostenible de tu empresa."
  },
  {
    icon: Users,
    title: "Gestión de Equipos",
    description: "Mejoramos la productividad y cohesión de tu equipo con metodologías probadas."
  },
  {
    icon: Zap,
    title: "Transformación Digital",
    description: "Modernizamos tus procesos con tecnología de vanguardia y herramientas digitales."
  }
];

export function Services() {
  return (
    <section id="servicios" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl mb-4">Nuestros Servicios</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Ofrecemos una amplia gama de servicios diseñados para cubrir todas las necesidades de tu negocio
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center mb-4">
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl mb-2">{service.title}</h3>
                <p className="text-gray-600">{service.description}</p>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
